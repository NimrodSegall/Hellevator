using System;

namespace Zenject.SpaceFighter
{
    [Serializable]
    public class EnemyCommonSettings
    {
        public float AttackDistance = 15.0f;
    }
}
