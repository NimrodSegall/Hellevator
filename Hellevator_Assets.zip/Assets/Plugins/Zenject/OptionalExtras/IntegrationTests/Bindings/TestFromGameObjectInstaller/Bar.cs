﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromGameObjectInstaller
{
    public class Bar : MonoBehaviour
    {
    }
}
