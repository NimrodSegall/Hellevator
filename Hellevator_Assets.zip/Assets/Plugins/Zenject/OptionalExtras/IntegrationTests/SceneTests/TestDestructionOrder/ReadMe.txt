
To test destruction order, rename the RenameThisResources folder in this directory to Resources, then add TestDestructionOrder1 and TestDestructionOrder2 to build settings, then run TestDestructionOrder1 either in unity or in a build, then look at the log to verify destruction order

